
import os
import streamlit as st
from summarizer import llm_summarize, offline_summarize, transcribe_audio
from exporters import export_to_docx, export_to_markdown

st.set_page_config(page_title="MeetMind AI — Smart Meeting Summarizer", layout="wide")

st.title("MeetMind AI — Smart Meeting Summarizer")
st.markdown("Generate concise meeting summaries, action items, and sentiment.")

st.sidebar.header("Settings")
st.sidebar.text_input("LLM Model (info)", value=os.getenv("OPENAI_MODEL", "gpt-4o-mini"))
temp = st.sidebar.slider("Creativity (temperature)", 0.0, 1.0, 0.2, 0.1)
offline = not bool(os.getenv("OPENAI_API_KEY") or os.getenv("AZURE_OPENAI_API_KEY"))
if offline:
    st.sidebar.warning("Running in OFFLINE DEMO MODE (no API key detected). Results are heuristic.")
else:
    st.sidebar.success("LLM enabled.")

st.subheader("1) Provide meeting input")
col1, col2 = st.columns(2)
with col1:
    uploaded_audio = st.file_uploader("Upload audio (MP3/WAV/M4A)", type=["mp3", "wav", "m4a"], accept_multiple_files=False)
with col2:
    transcript_text = st.text_area("Or paste transcript here", height=200)

process_btn = st.button("Generate Summary")

result = None

if process_btn:
    if uploaded_audio is None and not transcript_text.strip():
        st.error("Please upload an audio file or paste a transcript.")
    else:
        if transcript_text.strip():
            transcript = transcript_text.strip()
        else:
            with open("_tmp_audio", "wb") as f:
                f.write(uploaded_audio.read())
            try:
                transcript = transcribe_audio("_tmp_audio")
            except Exception as e:
                st.error(f"Transcription failed: {e}")
                transcript = ""
        if not transcript:
            st.stop()

        with st.spinner("Summarizing..."):
            if offline:
                result = offline_summarize(transcript)
            else:
                result = llm_summarize(transcript, temperature=temp)

        st.success("Summary generated.")

if result:
    tab1, tab2, tab3 = st.tabs(["Summary", "Action Items", "Sentiment"]) 

    with tab1:
        if result.get("markdown"):
            st.markdown(result["markdown"])
        else:
            st.markdown("## Executive Summary")
            st.write(result.get("executive_summary", ""))
            st.markdown("## Key Points")
            for kp in result.get("key_points", []):
                st.write(f"- {kp}")
            st.markdown("## Decisions")
            for d in result.get("decisions", []):
                st.write(f"- {d}")
            st.markdown("## Risks / Blockers")
            for r in result.get("risks", []):
                st.write(f"- {r}")

    with tab2:
        st.markdown("### Action Items")
        if result.get("action_items"):
            st.table(result["action_items"])
        else:
            st.info("No action items detected. Try LLM mode for richer extraction.")

    with tab3:
        st.markdown("### Sentiment Snapshot")
        sent = result.get("sentiment", {})
        st.write(f"**Overall:** {sent.get('overall', 'Unknown')}")
        for obs in sent.get("observations", []):
            st.write(f"- {obs}")

    st.subheader("Export")
    colA, colB = st.columns(2)
    with colA:
        if st.button("Download DOCX"):
            path = export_to_docx(result, "meeting_summary.docx")
            with open(path, "rb") as f:
                st.download_button("Save DOCX", data=f, file_name="meeting_summary.docx")
    with colB:
        if st.button("Download Markdown"):
            path = export_to_markdown(result, "meeting_summary.md")
            with open(path, "rb") as f:
                st.download_button("Save Markdown", data=f, file_name="meeting_summary.md")

st.divider()
st.caption("Built by MeetMind AI. Offline mode uses heuristics; enable OpenAI/Azure OpenAI keys for best results.")
