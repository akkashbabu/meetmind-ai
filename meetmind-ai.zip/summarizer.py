
import os
import re
from typing import Dict, Any, List

USE_AZURE = bool(os.getenv("AZURE_OPENAI_ENDPOINT"))

try:
    from openai import OpenAI
    if USE_AZURE:
        client = OpenAI(
            base_url=os.getenv("AZURE_OPENAI_ENDPOINT") + "/openai/deployments/" + os.getenv("AZURE_OPENAI_DEPLOYMENT"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        )
        GPT_MODEL = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    else:
        client = OpenAI()
        GPT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
except Exception:
    client = None
    GPT_MODEL = None

POS_WORDS = {"good", "progress", "positive", "success", "win", "achieved", "improved", "resolved"}
NEG_WORDS = {"delay", "risk", "issue", "problem", "bug", "blocker", "negative", "concern"}


def chunk_text(text: str, max_chars: int = 8000) -> List[str]:
    return [text[i:i+max_chars] for i in range(0, len(text), max_chars)]


def offline_summarize(transcript: str) -> Dict[str, Any]:
    sentences = re.split(r"(?<=[.!?])\s+", transcript)
    exec_summary = " ".join(sentences[:6]) if sentences else transcript[:500]

    keywords = ["deadline", "timeline", "milestone", "budget", "scope", "risk", "decision", "action", "owner"]
    key_points = [s for s in sentences if any(k in s.lower() for k in keywords)][:8]
    decisions = [s for s in sentences if any(w in s.lower() for w in ["decide", "decided", "agreed", "approve", "approved"])]
    risks = [s for s in sentences if any(w in s.lower() for w in ["risk", "issue", "blocker", "delay"])]

    action_items = []
    for s in sentences:
        m = re.search(r"([A-Z][a-zA-Z]+)\s+(will|shall|needs to|to)\s+(.+)", s)
        if m:
            owner = m.group(1)
            item = m.group(3)
            action_items.append({"Item": item.strip(), "Owner": owner, "Due Date": "", "Priority": "", "Notes": ""})
    if not action_items:
        for s in sentences:
            if re.match(r"^(Follow up|Send|Prepare|Review|Align|Update|Share|Draft)", s.strip(), flags=re.I):
                action_items.append({"Item": s.strip(), "Owner": "", "Due Date": "", "Priority": "", "Notes": ""})

    pos = sum(1 for w in POS_WORDS if w in transcript.lower())
    neg = sum(1 for w in NEG_WORDS if w in transcript.lower())
    overall = "Positive" if pos > neg else ("Negative" if neg > pos else "Neutral")

    return {
        "executive_summary": exec_summary,
        "key_points": key_points,
        "decisions": decisions,
        "risks": risks,
        "action_items": action_items,
        "sentiment": {
            "overall": overall,
            "observations": [f"Positive cues: {pos}", f"Negative cues: {neg}", "Heuristic offline estimate; enable API for deeper insights."],
        },
    }


def llm_summarize(transcript: str, temperature: float = 0.2) -> Dict[str, Any]:
    if client is None:
        return offline_summarize(transcript)
    from prompts import SYSTEM_PROMPT
    chunks = chunk_text(transcript)
    responses_md = []
    for ch in chunks:
        resp = client.chat.completions.create(
            model=GPT_MODEL,
            messages=[{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": ch}],
            temperature=temperature,
        )
        responses_md.append(resp.choices[0].message.content)
    merged_md = "

".join(responses_md)

    # Simple extraction attempts
    def extract_list(keyword: str) -> List[str]:
        return [line.strip("- ") for line in merged_md.splitlines() if keyword in line.lower()]

    action_items = []
    for line in merged_md.splitlines():
        if "|" in line and any(h in line.lower() for h in ["owner", "due", "priority"]):
            continue
        if "|" in line:
            cells = [c.strip() for c in line.split("|")]
            if len(cells) >= 5 and cells[0] and cells[1]:
                action_items.append({"Item": cells[0], "Owner": cells[1], "Due Date": cells[2], "Priority": cells[3], "Notes": cells[4]})

    sentiment = offline_summarize(transcript)["sentiment"]
    return {"markdown": merged_md, "key_points": extract_list("key"), "decisions": extract_list("decision"), "risks": extract_list("risk"), "action_items": action_items, "sentiment": sentiment}
