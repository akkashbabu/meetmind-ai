
from typing import Dict, Any, List
from docx import Document
import datetime


def export_to_docx(data: Dict[str, Any], path: str) -> str:
    doc = Document()
    doc.add_heading('MeetMind AI — Meeting Summary', 0)
    doc.add_paragraph(f"Generated on: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}
")

    def add_section(title: str, content):
        doc.add_heading(title, level=1)
        if isinstance(content, list):
            for item in content:
                doc.add_paragraph(str(item), style='List Bullet')
        else:
            doc.add_paragraph(str(content))

    if data.get('executive_summary'):
        add_section('Executive Summary', data['executive_summary'])

    add_section('Key Points', data.get('key_points', []))
    add_section('Decisions', data.get('decisions', []))
    add_section('Risks / Blockers', data.get('risks', []))

    doc.add_heading('Action Items', level=1)
    table = doc.add_table(rows=1, cols=5)
    hdr_cells = table.rows[0].cells
    headers = ['Item', 'Owner', 'Due Date', 'Priority', 'Notes']
    for i, h in enumerate(headers):
        hdr_cells[i].text = h
    for ai in data.get('action_items', []):
        row_cells = table.add_row().cells
        row_cells[0].text = str(ai.get('Item', ''))
        row_cells[1].text = str(ai.get('Owner', ''))
        row_cells[2].text = str(ai.get('Due Date', ''))
        row_cells[3].text = str(ai.get('Priority', ''))
        row_cells[4].text = str(ai.get('Notes', ''))

    doc.add_heading('Sentiment', level=1)
    sent = data.get('sentiment', {})
    doc.add_paragraph(f"Overall: {sent.get('overall', 'Unknown')}")
    for obs in sent.get('observations', []):
        doc.add_paragraph(obs, style='List Bullet')

    doc.save(path)
    return path


def export_to_markdown(data: Dict[str, Any], path: str) -> str:
    lines: List[str] = []
    lines.append('# MeetMind AI — Meeting Summary')
    lines.append('')
    if data.get('executive_summary'):
        lines.append('## Executive Summary')
        lines.append(str(data['executive_summary']))
        lines.append('')
    lines.append('## Key Points')
    for kp in data.get('key_points', []):
        lines.append(f"- {kp}")
    lines.append('')
    lines.append('## Decisions')
    for d in data.get('decisions', []):
        lines.append(f"- {d}")
    lines.append('')
    lines.append('## Risks / Blockers')
    for r in data.get('risks', []):
        lines.append(f"- {r}")
    lines.append('')
    lines.append('## Action Items')
    lines.append('| Item | Owner | Due Date | Priority | Notes |')
    lines.append('|---|---|---|---|---|')
    for ai in data.get('action_items', []):
        lines.append(f"| {ai.get('Item','')} | {ai.get('Owner','')} | {ai.get('Due Date','')} | {ai.get('Priority','')} | {ai.get('Notes','')} |")
    lines.append('')
    lines.append('## Sentiment')
    sent = data.get('sentiment', {})
    lines.append(f"**Overall:** {sent.get('overall', 'Unknown')}")
    for obs in sent.get('observations', []):
        lines.append(f"- {obs}")
    content = "
".join(lines)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    return path
