# MeetMind AI — Smart Meeting Summarizer

MeetMind AI is an intelligent agent that transcribes meeting audio (or accepts pasted transcripts) and generates concise summaries, action items, decisions, risks, and sentiment insights. It also exports results to DOCX and Markdown.

## Features
- Upload meeting **audio** (MP3/WAV/M4A) or **paste transcript**
- **Transcription** via Whisper (OpenAI API) or skip if transcript provided
- **Structured summary**: key points, decisions, risks, blockers
- **Action items** with owners and due dates
- **Sentiment snapshot** of the discussion
- **Exports**: DOCX and Markdown
- **Offline demo mode** if no API key set (basic heuristics)

## Tech Stack
- Python, Streamlit
- OpenAI API (GPT for summarization; Whisper for transcription)
- python-docx (DOCX export)

## Setup
1. **Clone / Download** this repository.
2. Ensure Python 3.10+ is installed.
3. Create a virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```
4. Set environment variables:
   - **OpenAI (default):**
     ```bash
     export OPENAI_API_KEY=your_key_here
     export OPENAI_MODEL=gpt-4o-mini
     ```
   - **Azure OpenAI (optional):**
     ```bash
     export AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
     export AZURE_OPENAI_API_KEY=your_key_here
     export AZURE_OPENAI_DEPLOYMENT=your_deployment_name  # e.g., gpt-4o-mini
     ```

## Run the app
```bash
streamlit run app.py
```
Open the local URL shown (e.g., http://localhost:8501) and try with `sample_transcript.txt`.

## Deploy (to get a Demo Link)
### Streamlit Community Cloud
1. Push this project to a **public GitHub repository**.
2. Go to https://share.streamlit.io and **Deploy an app** pointing to `app.py`.
3. Add secrets in Streamlit (**Settings → Secrets**):
   ```
   OPENAI_API_KEY = "..."
   AZURE_OPENAI_ENDPOINT = "..."  # if using Azure
   AZURE_OPENAI_API_KEY = "..."
   AZURE_OPENAI_DEPLOYMENT = "..."
   ```
4. Share the generated URL as your **Agent Demo link**.

### Hugging Face Spaces (Streamlit runtime)
1. Create a new Space (type: **Streamlit**).
2. Upload repo files and set **Environment Variables** in Space settings.
3. The Space URL becomes your **Agent Demo link**.

## File Overview
- `app.py` — Streamlit UI
- `summarizer.py` — Core agent logic (LLM + offline heuristics)
- `exporters.py` — DOCX/Markdown export helpers
- `prompts.py` — System & formatting prompts for high-quality outputs
- `requirements.txt` — Dependencies
- `sample_transcript.txt` — Test transcript

## Notes
- Offline mode uses simple heuristics for demo; enable API keys for best results.
- Prefer **Azure OpenAI** for enterprise deployments and compliance.

## License
MIT
